#pragma once

#include <vector>
#include <cmath>
#include "mapreduce_spec.h"


/* CS6210_TASK: Create your own data structure here, where you can hold information about file splits,
     that your master would use for its own bookkeeping and to convey the tasks to the workers for mapping */
typedef struct FileShard {
     vector<string> file_names;
     vector<int> start_pos;
     vector<int> end_pos;
     int shard_idx;
} FileShard;

inline vector<int> get_file_sizes_in_kb(vector<string> input_file_names) {
     vector<int> input_file_sizes;
     for(int i = 0;i < input_file_names.size();i++) {
          ifstream input_file;
          string input_file_name = input_file_names.at(i);
          input_file.open(input_file_name);

          input_file.seekg(0, ios::end);
          int input_file_size = input_file.tellg();
          
          input_file_sizes.push_back(max((int) (input_file_size/1000.0), 1));
     }
     return input_file_sizes;
}

inline vector<int> get_num_lines_in_file(vector<string> input_file_names) {
     vector<int> num_lines;
     for(int i = 0;i < input_file_names.size();i++) {
          ifstream input_file;
          int line_count = 0;
          string input_file_name = input_file_names.at(i);
          input_file.open(input_file_name);

          string line;
          while(std::getline(input_file, line)) {
               line_count++;
          }
          num_lines.push_back(line_count);
	}
     return num_lines;
}

inline void debug_file_shards(std::vector<FileShard>& fileShards) {
     for(int i = 0;i < fileShards.size();i++) {
          FileShard shard = fileShards.at(i);

          cout << "Shard: " << shard.shard_idx << endl;
          for(int j = 0;j < shard.file_names.size();j++) {
               cout << "    Input file    : " << shard.file_names.at(j) << endl;
               cout << "    Start position: " << shard.start_pos.at(j) << endl;
               cout << "    End position  : " << shard.end_pos.at(j) << endl;
          }
     }
}

/* CS6210_TASK: Create fileshards from the list of input files, map_kilobytes etc. using mr_spec you populated  */ 
inline bool shard_files(const MapReduceSpec& mr_spec, std::vector<FileShard>& fileShards) {
     vector<string> input_file_names = mr_spec.input_files;
     vector<int> input_file_sizes_kb = get_file_sizes_in_kb(input_file_names); // kilobytes
     vector<int> input_file_line_nums = get_num_lines_in_file(input_file_names);
  
     int all_files_total_size_in_kb = 0;
     for(int i = 0;i < input_file_sizes_kb.size();i++) {
          cout << input_file_names.at(i) <<  " " << input_file_sizes_kb.at(i) << " " +  input_file_line_nums.at(i) << endl;
          all_files_total_size_in_kb += input_file_sizes_kb.at(i);
     }
     int n_shards = (int) ceil(all_files_total_size_in_kb/(double)(mr_spec.map_kilobytes));
     cout << "Total size of all files: " << all_files_total_size_in_kb << endl;
     cout << "Total number of shards : " << n_shards << endl;

     int curr_file_idx = 0;
     int curr_file_offset = 0;
     int max_shard_size = mr_spec.map_kilobytes;

     for(int i = 0;i < n_shards;i++) {
          FileShard shard;
          int curr_shard_size = 0;
          shard.shard_idx = i;

          while(curr_shard_size < max_shard_size && curr_file_idx < input_file_names.size()) {
               string input_file_name = input_file_names.at(curr_file_idx);
               int input_file_total_size = input_file_sizes_kb.at(curr_file_idx);
               int input_file_line_count =  input_file_line_nums.at(curr_file_idx);

               int file_size_left_to_be_stored = (int) (input_file_line_count - curr_file_offset) * input_file_total_size/input_file_line_count;

               if(file_size_left_to_be_stored > (max_shard_size - curr_shard_size)) {
                    // Whole file can't be stored in current shard
                    int n_lines_that_can_be_stored = (int) (max_shard_size - curr_shard_size) * (input_file_line_count - curr_file_offset)/file_size_left_to_be_stored;

                    shard.file_names.push_back(input_file_name);
                    shard.start_pos.push_back(curr_file_offset);
                    shard.end_pos.push_back(curr_file_offset + n_lines_that_can_be_stored);

                    curr_file_offset += n_lines_that_can_be_stored + 1;
                    
                    curr_shard_size = max_shard_size; // Do this to get out of the loop since capacity is met
               } else {
                    // Whole file can be stored in current shard
                    shard.file_names.push_back(input_file_name);
                    shard.start_pos.push_back(curr_file_offset);
                    shard.end_pos.push_back(input_file_line_count);

                    curr_file_idx++;
                    curr_file_offset = 0;

                    curr_shard_size += file_size_left_to_be_stored;
               }
          }
          fileShards.push_back(shard);
     }

     debug_file_shards(fileShards);

	return true;
}
