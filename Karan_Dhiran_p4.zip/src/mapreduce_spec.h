#pragma once

#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include <map>
#include <cstring>

using namespace std;


/* CS6210_TASK: Create your data structure here for storing spec from the config file */
typedef struct MapReduceSpec {
	int n_workers;
	vector<string> worker_ipaddr_ports;
	vector<string> input_files;
	string output_dir;
	int n_output_files;
	int map_kilobytes;
	string user_id;
} MapReduceSpec;


inline vector<string> read_file_and_extract_lines(const std::string& config_filename) {
	string line;
	vector<string> lines;
	ifstream ifstream_file(config_filename);

	while(std::getline(ifstream_file, line)) {
		lines.push_back(line);
	}

	return lines;
}

inline map<string, string> get_key_value_pairs(vector<string> lines) {
	map<string, string> key_value_pairs;
	for(int i = 0;i < lines.size();i++) {
		string line = lines.at(i);

		int delim_idx = line.find("=");
		if(delim_idx != string::npos) {
			string key = line.substr(0, delim_idx);
			string value = line.substr(delim_idx+1, line.size());
			key_value_pairs[key] = value;
		}
	}
	return key_value_pairs;
}

inline vector<string> split_by_delim(string str, string delim) {
	vector<string> tokens;
	string tmp_value = str;
	int delim_idx = tmp_value.find(delim);
		
	while(delim_idx != string::npos) {
		string token = tmp_value.substr(0, delim_idx);
		tokens.push_back(token);

		tmp_value = tmp_value.substr(delim_idx+1, tmp_value.size());
		delim_idx = tmp_value.find(delim);
	}
	tokens.push_back(tmp_value);

	return tokens;
}

inline void set_spec_params(MapReduceSpec& mr_spec, map<string, string> key_value_pairs) {
	for(auto i = key_value_pairs.begin();i != key_value_pairs.end();i++) {
		string key = i->first;
		string value = i->second;

		if(key.compare("n_workers") == 0) {
			mr_spec.n_workers = stoi(value);
		} else if(key.compare("output_dir") == 0) {
			mr_spec.output_dir = value;
		} else if(key.compare("user_id") == 0) {
			mr_spec.user_id = value;
		} else if(key.compare("n_output_files") == 0) {
			mr_spec.n_output_files = stoi(value);
		} else if(key.compare("map_kilobytes") == 0) {
			mr_spec.map_kilobytes = stoi(value);
		} else if(key.compare("worker_ipaddr_ports") == 0) {
			mr_spec.worker_ipaddr_ports = split_by_delim(value, ",");
		} else if(key.compare("input_files") == 0) {
			mr_spec.input_files = split_by_delim(value, ",");
		}
	}
}

/* CS6210_TASK: Populate MapReduceSpec data structure with the specification from the config file */
inline bool read_mr_spec_from_config_file(const std::string& config_filename, MapReduceSpec& mr_spec) {
	try {
		// Read file
		vector<string> lines_in_file = read_file_and_extract_lines(config_filename);

		// Get key value pairs
		map<string, string> key_value_pairs = get_key_value_pairs(lines_in_file);

		// Set spec params
		set_spec_params(mr_spec, key_value_pairs);
	
		return true;
	} catch(int err) {
		cout << "Failed to read file, something went wrong..." << endl;
		return false;
	}
}


/* CS6210_TASK: validate the specification read from the config file */
inline bool validate_mr_spec(const MapReduceSpec& mr_spec) {
	bool all_cheks_pass = true;
	
	// Rule 1: Number of workers should be equal to the worker address ports specified
	if(mr_spec.n_workers != mr_spec.worker_ipaddr_ports.size()) {
		cout << "The number of worker address ports and the number of workers is not equal" << endl;
		all_cheks_pass = false;
	}

	// Rule 2: Input files existence
	for(int i = 0;i < mr_spec.input_files.size();i++) {
		string input_file_name = mr_spec.input_files.at(i);
		ifstream input_file;
		input_file.open(input_file_name);

		if(input_file) {
			// Do nothing in this case
		} else {
			cout << "Input file: " << input_file_name << " doesn't exist" << endl;
			all_cheks_pass = false;
		}
	}

	return all_cheks_pass;
}
