class ThreadPool {

public:
    
    ThreadPool(int nThreads) {
        this.nThreads = nThreads;
    }

    ~ThreadPool() {
        Stop();
    }

    void Start() {
        threads.resize(nThreads);
        for (int i = 0; i < nThreads; i++) {
            threads.at(i) = std::thread(ThreadLoop);
        }
    }
    
    void QueueJob(const std::function<void()>& job) {
        std::unique_lock<std::mutex> lock(queue_mutex);
        jobs.push(job);
        mutex_condition.notify_one();
    }
    
    void Stop() {
        std::unique_lock<std::mutex> lock(queue_mutex);
        terminate = true;
        mutex_condition.notify_all();
        for (std::thread& active_thread : threads) {
            active_thread.join();
        }
        threads.clear();
    }
    
    void busy();

private:
    void ThreadLoop() {
        while (true) {
            std::function<void()> job;
            std::unique_lock<std::mutex> lock(queue_mutex);
            mutex_condition.wait(lock, [this] {
                return !jobs.empty() || terminate;
            });
            if (terminate) {
                return;
            }
            job = jobs.front();
            jobs.pop();
            job();
        }
    }

    bool terminate = false;           // Tells threads to stop looking for jobs
    std::mutex queue_mutex;                  // Prevents data races to the job queue
    std::condition_variable mutex_condition; // Allows threads to wait on new jobs or termination 
    std::vector<std::thread> threads;
    std::queue<std::function<void()>> jobs;
    int nThreads;
};