#pragma once

#include <mr_task_factory.h>
#include "mr_tasks.h"
#include <fstream>
#include <cstring>
#include <vector>
#include <map>

# include <grpc++/grpc++.h>

# include "masterworker.grpc.pb.h"
# include "masterworker.pb.h"
# include "file_shard.h"

using namespace masterworker;
using namespace grpc;

using grpc::Server;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::Status;
using masterworker::MasterWorkerCommService;
using masterworker::TaskReturnStatus;
using masterworker::Task;

using namespace std;


bool alphabetical_comparator(pair<string, string> a, pair<string, string> b) {
	return a.first < b.first;
}

/* CS6210_TASK: Handle all the task a Worker is supposed to do.
	This is a big task for this project, will test your understanding of map reduce */
class Worker final : public MasterWorkerCommService::Service {

	public:
		/* DON'T change the function signature of this constructor */
		Worker(std::string ip_addr_port);

		/* DON'T change this function's signature */
		bool run();

		void run_server();

		void map(FileShard shard, string user_id, string output_file_name);

		void reduce(FileShard shard, string user_id, string output_file_name);

	private:
		/* NOW you can add below, data members and member functions as per the need of your implementation*/
		string ip_addr_port;

		Status AssignTask(ServerContext* context, const Task* request,
                    TaskReturnStatus* reply) override {
      		string task_type = request->task_type();
			string user_id = request->user_id();
			int shard_idx = request->shard_idx();
			string output_file_name = request->output_file();

			vector<string> file_names(request->file_names().begin(), request->file_names().end());
			vector<int> start_pos(request->start_pos().begin(), request->start_pos().end());
			vector<int> end_pos(request->end_pos().begin(), request->end_pos().end());
			
			// Create file_shard to be processed
			FileShard shard;
			shard.shard_idx = shard_idx;
			shard.file_names = file_names;
			shard.start_pos = start_pos;
			shard.end_pos = end_pos;

			if(task_type.compare("Map") == 0) {
				map(shard, user_id, output_file_name);
			} else if(task_type.compare("Reduce") == 0) {
				reduce(shard, user_id, output_file_name);
			}

      		return Status::OK;
    	}

    std::hash<std::string> hasher_;
    const std::string id_;
};


/* CS6210_TASK: ip_addr_port is the only information you get when started.
	You can populate your other class data members here if you want */
Worker::Worker(std::string ip_addr_port) {
	this->ip_addr_port = ip_addr_port;
}

extern std::shared_ptr<BaseMapper> get_mapper_from_task_factory(const std::string& user_id);
extern std::shared_ptr<BaseReducer> get_reducer_from_task_factory(const std::string& user_id);


void Worker::run_server()   {
  ServerBuilder builder;
  builder.AddListeningPort(this->ip_addr_port, grpc::InsecureServerCredentials());
  builder.RegisterService(this);

  std::unique_ptr<Server> server(builder.BuildAndStart());
  // std::cout << "Server listening on " << server_addressess << std::endl;

  server->Wait();
}



void Worker::map(FileShard shard, string user_id, string output_file_name) {
	auto mapper = get_mapper_from_task_factory(user_id);

	for(int i = 0;i < shard.file_names.size();i++) {
		string file_name = shard.file_names.at(i);
		int file_start_pos = shard.start_pos.at(i);
		int file_end_pos = shard.end_pos.at(i);

		ifstream input_file;
		input_file.open(file_name);

		string line;
		for(int j = 0;j <= file_end_pos;j++) {
			std::getline(input_file, line);
			if(j >= file_start_pos) {
				mapper->map(line);
			}
		}

		ofstream output_file(output_file_name);

		vector<pair<string, string>> key_val_pairs = mapper->impl_->stored_key_value_pairs;
		sort(key_val_pairs.begin(), key_val_pairs.end(), alphabetical_comparator);

		for(int i = 0;i < key_val_pairs.size();i++) {
			pair<string, string> key_val_pair = key_val_pairs[i];
			string key = key_val_pair.first;
			string value = key_val_pair.second;

			output_file << key << "," << value << endl;
		}
	}
}

void Worker::reduce(FileShard shard, string user_id, string output_file_name) {
	cout << "Running reduce task on file: " << output_file_name << endl;
	auto reducer = get_reducer_from_task_factory(user_id);

	std::map<string, vector<string>> word_count_cache;
	for(int i = 0;i < shard.file_names.size();i++) {
		string file_name = shard.file_names.at(i);
		int file_start_pos = shard.start_pos.at(i);
		int file_end_pos = shard.end_pos.at(i);

		cout << "Reduce task file name: " << file_name << ", start_pos: " << file_start_pos << ", end_pos: " << file_end_pos << endl;

		ifstream input_file;
		input_file.open(file_name);

		string line;
		string curr_key = "";

		for(int j = 0;j <= file_end_pos;j++) {
			std::getline(input_file, line);
			vector<string> values;
			if(j >= file_start_pos) {
				int delim_idx = line.find(",");
				string key = line.substr(0, delim_idx);
				string val = line.substr(delim_idx+1, line.size());

				word_count_cache[key].push_back(val);
			}
		}
	}

	for(auto word_inst: word_count_cache) {
		reducer->reduce(word_inst.first, word_inst.second);
	}

	ofstream output_file(output_file_name);
	for(auto word_count_inst: reducer->impl_->word_count) {
		string word = word_count_inst.first;
		int count = word_count_inst.second;

		if(count != 0) {
			output_file << word << " " << to_string(count) << endl;
		}

		// cout << "Word: " << word << ", count: " << to_string(count) << endl;
		
	}
}

/* CS6210_TASK: Here you go. once this function is called your woker's job is to keep looking for new tasks 
	from Master, complete when given one and again keep looking for the next one.
	Note that you have the access to BaseMapper's member BaseMapperInternal impl_ and 
	BaseReduer's member BaseReducerInternal impl_ directly, 
	so you can manipulate them however you want when running map/reduce tasks*/
bool Worker::run() {
	/*  Below 5 lines are just examples of how you will call map and reduce
		Remove them once you start writing your own logic */ 
	// std::cout << "worker.run(), I 'm not ready yet" <<std::endl;
	// auto mapper = get_mapper_from_task_factory("cs6210");
	// mapper->map("I m just a 'dummy', a \"dummy line\"");
	// auto reducer = get_reducer_from_task_factory("cs6210");
	// reducer->reduce("dummy", std::vector<std::string>({"1", "1"}));
	run_server();
	return true;
}
