#include <mr_task_factory.h>
#include "mr_tasks.h"
#include <fstream>
#include <cstring>
#include <vector>
#include <map>

#include <iostream>
#include <string>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <queue>

# include <grpc++/grpc++.h>

# include "masterworker.grpc.pb.h"
# include "masterworker.pb.h"
# include "file_shard.h"

using namespace masterworker;
using namespace grpc;

using grpc::Server;
using grpc::ServerBuilder;
using grpc::ServerContext;
using grpc::Status;
using masterworker::MasterWorkerCommService;
using masterworker::TaskReturnStatus;
using masterworker::Task;

using namespace std;



class ThreadPool {

public:
    
    ThreadPool(int nThreads) {
        this->nThreads = nThreads;
    }

    ~ThreadPool() {
        Stop();
    }

    void Start() {
	terminate = false;
        threads.resize(nThreads);
        for (int i = 0; i < nThreads; i++) {
            threads.at(i) = std::thread(&ThreadPool::ThreadLoop, this);
	}
	//cout << "Number of threads: " << nThreads << endl;
    }
    
    void QueueJob(const std::function<void()>& job) {
        std::unique_lock<std::mutex> lock(queue_mutex);
	notFull.wait(lock, [this]() {return true;});
	cout << "Pushing a new job" << endl;
        jobs.push(job);
        //mutex_condition.notify_one();
	notEmpty.notify_one();
    }
    
    void Stop() {
	cout << "Stop the threads" << endl;
        //std::unique_lock<std::mutex> lock(queue_mutex);
        terminate = true;
        //mutex_condition.notify_all();
	notFull.notify_all();
	notEmpty.notify_all();
	cout << "Joining on the threads" << endl;
        for (std::thread& active_thread : threads) {
       	    //mutex_condition.notify_all();
	    cout << "Some thread joined" << endl;
	    //cout << active_thread.join() << endl;
            active_thread.join();
        }
        threads.clear();
	cout << "All stopped" << endl;
    }
    
    void busy();

private:
    void ThreadLoop() {
        while (!terminate) {
            std::function<void()> job;
            std::unique_lock<std::mutex> lock(queue_mutex);
	    cout << "Waiting for the lock " << std::this_thread::get_id() << endl;
            //mutex_condition.wait(lock);
	    notEmpty.wait(lock, [this] {
		cout << "Is someone here? " << std::this_thread::get_id() << " " << (!jobs.empty() || terminate  == 1)<< endl;
                return !jobs.empty() || terminate;
            });
	    cout << "Lock released " << std::this_thread::get_id() << endl;
            if (terminate) {
		cout << "Terminating!" << endl;
                return;
            }
	    cout << "Got a job" << endl;
            job = jobs.front();
            jobs.pop();
	    notFull.notify_one();
            job();
	    cout << "Done" << endl;
        }
    }

    std::atomic_bool terminate;           // Tells threads to stop looking for jobs
    std::mutex queue_mutex;                  // Prevents data races to the job queue
    std::condition_variable mutex_condition; // Allows threads to wait on new jobs or termination 
    std::vector<std::thread> threads;
    std::queue<std::function<void()>> jobs;
    int nThreads;
    std::condition_variable notEmpty;
    std::condition_variable notFull;
};
