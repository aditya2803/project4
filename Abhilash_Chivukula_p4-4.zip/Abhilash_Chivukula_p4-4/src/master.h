#pragma once

#include <cmath>
#include <vector>
#include <cstdio>

# include <grpc++/grpc++.h>
#include <grpc/support/log.h>

# include "masterworker.grpc.pb.h"
# include "masterworker.pb.h"

#include "mapreduce_spec.h"
#include "file_shard.h"

#include "threadpool.h"

using grpc::Server;
using grpc::ServerAsyncResponseWriter;
using grpc::ServerBuilder;
using grpc::ServerCompletionQueue;
using grpc::ServerContext;
using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;
using grpc::ClientAsyncResponseReader;
using grpc::CompletionQueue;

using masterworker::Task;
using masterworker::TaskReturnStatus;
using masterworker::MasterWorkerCommService;


class WorkerClient {
 	private:
  		std::unique_ptr<MasterWorkerCommService::Stub> stub_;

	public:
		explicit WorkerClient(std::shared_ptr<Channel> channel)
      	: stub_(MasterWorkerCommService::NewStub(channel)) {}

		string AssignTask(FileShard shard, string task_type, string user_id, string output_file_path) {
			Task task;
			TaskReturnStatus taskReturnStatus;
			ClientContext client_ctx;
			CompletionQueue cq;
			Status return_status;

			//task.set_allocated_task_type(task_type);
			task.set_output_file(output_file_path);
			task.set_user_id(user_id);
			task.set_task_type(task_type);
			task.set_shard_idx(shard.shard_idx);

			for(int i = 0;i < shard.file_names.size();i++) {
				task.add_file_names(shard.file_names.at(i));
				task.add_start_pos(shard.start_pos.at(i));
				task.add_end_pos(shard.end_pos.at(i));
			}
			
			// Add more stuff

			// Async RPC code start
			std::unique_ptr<ClientAsyncResponseReader<TaskReturnStatus> > rpc(stub_->AsyncAssignTask(&client_ctx, task, &cq));
			rpc->Finish(&taskReturnStatus, &return_status, (void*)1);

			void* got_tag;
    		bool ok = false;

		    GPR_ASSERT(cq.Next(&got_tag, &ok));
    		GPR_ASSERT(got_tag == (void*)1);
    		GPR_ASSERT(ok);

			// Async RPC code end

			// Get required resuts from GRPC call
			
			if(return_status.ok()) {
				return output_file_path;
			} else {
				return "FAIL";
			}
		}
};

enum CurrentStatus {UNASSIGNED=0, PENDING=1, DONE=2};

/* CS6210_TASK: Handle all the bookkeeping that Master is supposed to do.
	This is probably the biggest task for this project, will test your understanding of map reduce */
class Master {

	public:
		/* DON'T change the function signature of this constructor */
		Master(const MapReduceSpec&, const std::vector<FileShard>&);

		/* DON'T change this function's signature */
		bool run();

	private:
		/* NOW you can add below, data members and member functions as per the need of your implementation*/
		MapReduceSpec mr_spec;
		vector<FileShard> file_shards;

		vector<FileShard> createReduceFileShards(vector<string> output_map_files);

		std::unique_ptr<ThreadPool> threadPool;

		std::condition_variable cond;

};


/* CS6210_TASK: This is all the information your master will get from the framework.
	You can populate your other class data members here if you want */
Master::Master(const MapReduceSpec& mr_spec, const std::vector<FileShard>& file_shards) {
	this->mr_spec = mr_spec;
	this->file_shards = file_shards;
	//Number of threads = Number of workers
	threadPool = make_unique<ThreadPool>(mr_spec.n_workers);
	threadPool->Start();
}

// Master::string chooseFreeWorker(map<string, CurrentStatus> workerStatus) {
// 	for(auto worker : workerStatus) {
// 		if(worker.second != PENDING) {
// 			return worker.first;
// 		}
// 	}
// 	return "None";
// }

vector<FileShard> Master::createReduceFileShards(vector<string> output_map_files) {
	int n_reduce_tasks = this->mr_spec.n_output_files;
	int n_map_output_files = output_map_files.size();
	vector<FileShard> reduceFileShards;

	cout << "createReduceFileShards: n_reduce_tasks-> " << n_reduce_tasks << ", n_map_output_files: " << n_map_output_files << endl;

	if(n_reduce_tasks == n_map_output_files) {
		for(int i = 0;i < output_map_files.size();i++) {
			FileShard shard;
			string output_file_name = output_map_files.at(i);

			ifstream output_file;
			output_file.open(output_file_name);

			int n_lines_output_file = 0;
			string line;
			while(getline(output_file, line)) {
				n_lines_output_file++;
			}

			cout << "Debug equal no of map and reduce tasks: " << output_file_name << " " << n_lines_output_file << endl;

			shard.shard_idx = i;
			shard.file_names.push_back(output_file_name);
			shard.start_pos.push_back(0);
			shard.end_pos.push_back(n_lines_output_file);

			reduceFileShards.push_back(shard);
		}

	} else if(n_reduce_tasks < n_map_output_files) {
		int file_limit_per_reducer_upper_limit = (int) ceil(n_map_output_files/(double)n_reduce_tasks);
		int file_limit_per_reducer_lower_limit = (int) floor(n_map_output_files/(double)n_reduce_tasks);
		int file_limit_per_reducer = file_limit_per_reducer_upper_limit;

		cout << "File limits: " << file_limit_per_reducer_lower_limit << " " << file_limit_per_reducer_upper_limit << " "
		<< file_limit_per_reducer << endl;

		//FileShard shard;
		int curr_shard_start_idx = 0;
		vector<string> file_names;
		vector<int> start_pos;
		vector<int> end_pos;

		for(int i = 0;i < output_map_files.size();i++) {
			string output_file_name = output_map_files.at(i);
			ifstream output_file;
			output_file.open(output_file_name);

			int n_lines_output_file = 0;
			string line;
			while(getline(output_file, line)) {
				n_lines_output_file++;
			}

			file_names.push_back(output_file_name);
			start_pos.push_back(0);
			end_pos.push_back(n_lines_output_file);

			if(i - curr_shard_start_idx + 1 >= file_limit_per_reducer) {
				cout << to_string(i) << " " << to_string(curr_shard_start_idx) << " " << to_string(file_limit_per_reducer) << endl;
				FileShard shard;
				
				shard.shard_idx = i;
				shard.file_names = file_names;
				shard.start_pos = start_pos;
				shard.end_pos = end_pos;

				reduceFileShards.push_back(shard);

				curr_shard_start_idx = i+1;

				if((n_reduce_tasks - reduceFileShards.size()) % file_limit_per_reducer_lower_limit == 0) {
					file_limit_per_reducer = file_limit_per_reducer_lower_limit;
				}

				file_names.clear();
				start_pos.clear();
				end_pos.clear();
			}
		}
	} else {
		double frac_of_file_in_each_reducer = n_map_output_files/(double) n_reduce_tasks;
		int n_shards_per_output_file_upper_limit = ceil(n_reduce_tasks/(double)n_map_output_files);
		int n_shards_per_output_file_lower_limit = floor(n_reduce_tasks/(double)n_map_output_files);
		int n_shards_per_output_file = n_shards_per_output_file_upper_limit;

		cout << to_string(n_shards_per_output_file) << " " << frac_of_file_in_each_reducer << endl;
		int shard_idx = 0;
		for(int i = 0;i < output_map_files.size();i++) {
			string output_file_name = output_map_files.at(i);
			ifstream output_file;
			output_file.open(output_file_name);

			int n_lines_output_file = 0;
			string line;
			while(getline(output_file, line)) {
				n_lines_output_file++;
			}
			
			int curr_shard_start_idx = 0;
			for(int j = 0;j < n_shards_per_output_file;j++) {
				FileShard shard;
				
				shard.shard_idx = shard_idx;
				shard.file_names.push_back(output_file_name);
				shard.start_pos.push_back(curr_shard_start_idx);

				int curr_shard_end_idx = (int) (curr_shard_start_idx + frac_of_file_in_each_reducer * n_lines_output_file);
				shard.end_pos.push_back(curr_shard_end_idx);

				cout << "Debug: " << to_string(curr_shard_start_idx) << " -> " << to_string(curr_shard_end_idx) << " -> "
				 << to_string(n_lines_output_file) << " -> " << to_string(frac_of_file_in_each_reducer) << endl;

				curr_shard_start_idx = curr_shard_end_idx+1;
				shard_idx++;
				reduceFileShards.push_back(shard);

				if((n_reduce_tasks - shard_idx) % n_shards_per_output_file_lower_limit == 0) {
					n_shards_per_output_file = n_shards_per_output_file_lower_limit;
				}
			}
		}
	}
	return reduceFileShards;
}

/* CS6210_TASK: Here you go. once this function is called you will complete whole map reduce task and return true if succeeded */
bool Master::run() {
	Task task_;
	TaskReturnStatus taskReturnStatus_;

	int n_shard = this->file_shards.size();
	map<int, CurrentStatus> mapTaskStatus;
	map<int, CurrentStatus> reduceTaskStatus;
	map<string, CurrentStatus> workerStatus;
	bool all_map_tasks_done = false;
	bool all_reduce_tasks_done = false;
	bool all_map_tasks_assigned = false;
	vector<string> map_output_files;
	vector<string> reduce_output_files;

	for(int i = 0;i < file_shards.size();i++) {
		FileShard file_shard = file_shards.at(i);
		mapTaskStatus[file_shard.shard_idx] = UNASSIGNED;
	}

	for(int i = 0;i < this->mr_spec.n_output_files;i++) {
		reduceTaskStatus[i] = UNASSIGNED;
	}

	for(int i = 0;i < mr_spec.n_workers;i++) {
		string worker_port = mr_spec.worker_ipaddr_ports.at(i);
		workerStatus[worker_port] = UNASSIGNED;
	}

	cout << "Starting map tasks..."  << all_map_tasks_done << endl;
	while(!all_map_tasks_done) {
		for(int i = 0;i < file_shards.size();i++) {
			threadPool->QueueJob([&, i]() {
				FileShard file_shard = file_shards.at(i);
				int file_shard_idx = file_shard.shard_idx;

				if(mapTaskStatus[file_shard_idx] == UNASSIGNED) {
					// string chosenWorker = chooseFreeWorker(workerStatus);
					string chosenWorker = this->mr_spec.worker_ipaddr_ports.at(0);
					WorkerClient worker_client(grpc::CreateChannel(chosenWorker, grpc::InsecureChannelCredentials()));
					string output_file_path = this->mr_spec.output_dir + "/" + chosenWorker + "_" + to_string(this->file_shards.at(i).shard_idx) + "_map.txt";
					string task_file_name = worker_client.AssignTask(this->file_shards.at(i), "Map", this->mr_spec.user_id, output_file_path);
					workerStatus[chosenWorker] = PENDING;

					//cout << "Chosen Worker: "  << chosenWorker << ", task file name: " << task_file_name << endl;
					if(chosenWorker.compare("None") != 0 && task_file_name.compare("FAIL") != 0) {
						cout << "Done procssing map task on shard: " << file_shard_idx << endl;
						mapTaskStatus[file_shard_idx] = DONE;
						map_output_files.push_back(task_file_name);
						workerStatus[chosenWorker] = UNASSIGNED;
					} else {
						cout << "Failed to run RPC task" << endl;
					}
				}
			});
		}

		all_map_tasks_done = true;
	// 	bool tmp_done = true;
	// 	for(int i = 0;i < file_shards.size();i++) {
	// 		FileShard file_shard = file_shards.at(i);
	// 		int file_shard_idx = file_shard.shard_idx;

	// 		cout << file_shard_idx << " : " <<  mapTaskStatus[file_shard_idx] << endl;
	// 		if(mapTaskStatus[file_shard_idx] != UNASSIGNED) {
	// 			tmp_done = false;
	// 			break;
	// 		}
	// 	}
	// 	all_map_tasks_done = tmp_done;
	// }
		cout << "All map tasks done!!" << endl;
	}

	cout << "Starting reduce tasks..."  << all_reduce_tasks_done << endl;
	vector<FileShard> reduceFileShards = createReduceFileShards(map_output_files);
	while(!all_reduce_tasks_done) {
		for(int i = 0;i < reduceFileShards.size();i++) {
			FileShard reducedFileShard = reduceFileShards.at(i);
			int file_shard_idx = reducedFileShard.shard_idx;
			string chosenWorker = this->mr_spec.worker_ipaddr_ports.at(0);
			WorkerClient worker_client(grpc::CreateChannel(chosenWorker, grpc::InsecureChannelCredentials()));
			
			string output_file_path = this->mr_spec.output_dir + "/" + chosenWorker + "_" + to_string(reduceFileShards.at(i).shard_idx) + "_reduce.txt";
			string task_file_name = worker_client.AssignTask(reduceFileShards.at(i), "Reduce", this->mr_spec.user_id, output_file_path);
			workerStatus[chosenWorker] = PENDING;

			//cout << "Chosen Worker: "  << chosenWorker << ", task file name: " << task_file_name << endl;
			if(chosenWorker.compare("None") != 0 && task_file_name.compare("FAIL") != 0) {
				cout << "Done procssing reduce task on shard: " << file_shard_idx << endl;
				reduceTaskStatus[file_shard_idx] = DONE;
				reduce_output_files.push_back(task_file_name);
				workerStatus[chosenWorker] = UNASSIGNED;
			} else {
				cout << "Failed to run RPC task" << endl;
			}
		}
		all_reduce_tasks_done = true;
	}

	bool debug_keep_map_files = false;

	if(!debug_keep_map_files) {
		// Cleanup map task intermediate files
		cout << "Cleaning up interim files from map task..." << endl;
		for(int i = 0;i < map_output_files.size();i++) {
			string map_output_file = map_output_files.at(i);
			int delete_status = remove(map_output_file.c_str());
		}
	}

	cout << "Done running map reduce" << endl;

	return true;
}