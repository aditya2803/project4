#pragma once

#include <cmath>
#include <vector>
#include <cstdio>
#include <chrono>
#include <thread>
#include <mutex>

# include <grpc++/grpc++.h>
#include <grpc/support/log.h>

# include "masterworker.grpc.pb.h"
# include "masterworker.pb.h"

#include "mapreduce_spec.h"
#include "file_shard.h"

using grpc::Server;
using grpc::ServerAsyncResponseWriter;
using grpc::ServerBuilder;
using grpc::ServerCompletionQueue;
using grpc::ServerContext;
using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;
using grpc::ClientAsyncResponseReader;
using grpc::CompletionQueue;

using masterworker::Task;
using masterworker::TaskReturnStatus;
using masterworker::MasterWorkerCommService;

class WorkerClient {
 	private:
  		std::unique_ptr<MasterWorkerCommService::Stub> stub_;

	public:
		explicit WorkerClient(std::shared_ptr<Channel> channel)
      	: stub_(MasterWorkerCommService::NewStub(channel)) {}

		string AssignTask(FileShard shard, string task_type, string user_id, string output_file_path, int n_output_files) {
			Task task;
			TaskReturnStatus taskReturnStatus;
			ClientContext client_ctx;
			CompletionQueue cq;
			Status return_status;

			// Set timeout
			auto deadline = std::chrono::system_clock::now() + std::chrono::milliseconds(2 * 60 * 1000);
			client_ctx.set_deadline(deadline);

			//task.set_allocated_task_type(task_type);
			task.set_output_file(output_file_path);
			task.set_user_id(user_id);
			task.set_task_type(task_type);
			task.set_shard_idx(shard.shard_idx);
			task.set_n_reducers(n_output_files);

			for(int i = 0;i < shard.file_names.size();i++) {
				task.add_file_names(shard.file_names.at(i));
				task.add_start_pos(shard.start_pos.at(i));
				task.add_end_pos(shard.end_pos.at(i));
			}
			
			// Add more stuff

			// Async RPC code start
			std::unique_ptr<ClientAsyncResponseReader<TaskReturnStatus> > rpc(stub_->AsyncAssignTask(&client_ctx, task, &cq));
			rpc->Finish(&taskReturnStatus, &return_status, (void*)1);

			void* got_tag;
    		bool ok = false;

		    GPR_ASSERT(cq.Next(&got_tag, &ok));
    		GPR_ASSERT(got_tag == (void*)1);
    		GPR_ASSERT(ok);

			// Async RPC code end

			// Get required resuts from GRPC call
			
			if(return_status.ok()) {
				return output_file_path;
			} else {
				return "FAIL";
			}
		}
};

enum CurrentStatus {UNASSIGNED=0, PENDING=1, DONE=2, UNRESPONSIVE=3};

/* CS6210_TASK: Handle all the bookkeeping that Master is supposed to do.
	This is probably the biggest task for this project, will test your understanding of map reduce */
class Master {

	public:
		/* DON'T change the function signature of this constructor */
		Master(const MapReduceSpec&, const std::vector<FileShard>&);

		/* DON'T change this function's signature */
		bool run();

	private:
		/* NOW you can add below, data members and member functions as per the need of your implementation*/
		MapReduceSpec mr_spec;
		vector<FileShard> file_shards;
		vector<FileShard> reduceFileShards;

		map<int, CurrentStatus> mapTaskStatus;
		map<int, CurrentStatus> reduceTaskStatus;
	 	map<string, CurrentStatus> workerStatus;

		bool all_map_tasks_done = false;
		bool all_reduce_tasks_done = false;
		vector<string> map_output_files;
		vector<string> reduce_output_files;

		std::mutex taskStatusMutex;

		vector<FileShard> createReduceFileShards(vector<string> output_map_files);

		void run_map_task(string worker);
		void run_reducer_task(string worker);

};

/* CS6210_TASK: This is all the information your master will get from the framework.
	You can populate your other class data members here if you want */
Master::Master(const MapReduceSpec& mr_spec, const std::vector<FileShard>& file_shards) {
	this->mr_spec = mr_spec;
	this->file_shards = file_shards;


	for(int i = 0;i < file_shards.size();i++) {
		FileShard file_shard = file_shards.at(i);
		mapTaskStatus[file_shard.shard_idx] = UNASSIGNED;
	}

	for(int i = 0;i < this->mr_spec.n_output_files;i++) {
		reduceTaskStatus[i] = UNASSIGNED;
	}
}

vector<FileShard> Master::createReduceFileShards(vector<string> output_map_files) {
	int n_reduce_tasks = this->mr_spec.n_output_files;
	vector<FileShard> reduceFileShards;

	for(int i = 0;i < n_reduce_tasks;i++) {
		FileShard shard;
		vector<string> file_names;
		vector<int> start_pos;
		vector<int> end_pos;
		// For reduce start_pos and end_pos don't really matter

		shard.shard_idx = i;

		for(int j = 0;j < output_map_files.size();j++) {
			string file_name = output_map_files.at(j) + "." + to_string(i);
			file_names.push_back(file_name);
			start_pos.push_back(0);
			end_pos.push_back(0);
		}
		shard.file_names = file_names;
		shard.start_pos = start_pos;
		shard.end_pos = end_pos;

		reduceFileShards.push_back(shard);
	}

	return reduceFileShards;
}

void Master::run_map_task(string worker) {
	while(1) {
		int selected_shard_idx = -1;

		// Unresponsive worker will not serve requests
		if(workerStatus[worker] == UNRESPONSIVE) {
			break;
		}

		taskStatusMutex.lock();
		int n_complete_map_tasks = 0;
		for(int i = 0;i < file_shards.size();i++) {
			if(mapTaskStatus[i] == UNASSIGNED) {
				selected_shard_idx = i;
				break;
			}
			if(mapTaskStatus[i] == DONE) {
				n_complete_map_tasks++;
			}
		}
		if(selected_shard_idx != -1) {
			mapTaskStatus[selected_shard_idx] = PENDING;
		}
		taskStatusMutex.unlock();

		if(n_complete_map_tasks == file_shards.size()) {
			// Break since all tasks are done
			break;
		}

		if(selected_shard_idx != -1) {
			FileShard file_shard = file_shards.at(selected_shard_idx);
			int file_shard_idx = file_shard.shard_idx;

			string chosenWorker = worker;
			cout << "Chosen worker: " << chosenWorker << " for shard idx: " << selected_shard_idx << endl;
			
			WorkerClient worker_client(grpc::CreateChannel(chosenWorker, grpc::InsecureChannelCredentials()));
			string output_file_path = this->mr_spec.output_dir + "/" + chosenWorker + "_" + to_string(this->file_shards.at(selected_shard_idx).shard_idx) + "_map.txt";
			string task_file_name = worker_client.AssignTask(this->file_shards.at(selected_shard_idx), "Map", this->mr_spec.user_id, output_file_path, this->mr_spec.n_output_files);

			if(chosenWorker.compare("None") != 0 && task_file_name.compare("FAIL") != 0) {
				cout << "Done procssing map task on shard: " << file_shard_idx << endl;
				taskStatusMutex.lock();
				mapTaskStatus[file_shard_idx] = DONE;
				map_output_files.push_back(task_file_name);
				taskStatusMutex.unlock();
			} else {
				cout << "Failed to run RPC task" << endl;
				taskStatusMutex.lock();
				mapTaskStatus[file_shard_idx] = UNASSIGNED;
				workerStatus[worker] = UNRESPONSIVE;
				taskStatusMutex.unlock();
			}
		}
	}
}

void Master::run_reducer_task(string worker) {
	while(1) {
		int selected_shard_idx = -1;

		// Unresponsive worker will not serve requests
		if(workerStatus[worker] == UNRESPONSIVE) {
			break;
		}

		taskStatusMutex.lock();
		int n_complete_reduce_tasks = 0;
		for(int i = 0;i < reduceFileShards.size();i++) {
			if(reduceTaskStatus[i] == UNASSIGNED) {
				selected_shard_idx = i;
				break;
			}
			if(reduceTaskStatus[i] == DONE) {
				n_complete_reduce_tasks++;
			}
		}
		if(selected_shard_idx != -1) {
			reduceTaskStatus[selected_shard_idx] = PENDING;
		}
		taskStatusMutex.unlock();

		if(n_complete_reduce_tasks == reduceFileShards.size()) {
			// Break since all tasks are done
			break;
		}

		if(selected_shard_idx != -1) {
			FileShard reducedFileShard = reduceFileShards.at(selected_shard_idx);
			int file_shard_idx = reducedFileShard.shard_idx;
			
			string chosenWorker = worker;
			WorkerClient worker_client(grpc::CreateChannel(chosenWorker, grpc::InsecureChannelCredentials()));
				
			string output_file_path = this->mr_spec.output_dir + "/" + chosenWorker + "_" + to_string(reduceFileShards.at(selected_shard_idx).shard_idx) + "_reduce.txt";
			cout << "ReduceFileShards size: " << reduceFileShards.size() << ", selected_shard_idx: " << selected_shard_idx << endl;
			string task_file_name = worker_client.AssignTask(reduceFileShards.at(selected_shard_idx), "Reduce", this->mr_spec.user_id, output_file_path, selected_shard_idx);

			cout << "Chosen Worker: "  << chosenWorker << ", task file name: " << task_file_name << endl;
			if(chosenWorker.compare("None") != 0 && task_file_name.compare("FAIL") != 0) {
				cout << "Done procssing reduce task on shard: " << file_shard_idx << endl;
				taskStatusMutex.lock();
				reduceTaskStatus[file_shard_idx] = DONE;
				reduce_output_files.push_back(task_file_name);
				taskStatusMutex.unlock();
			} else {
				cout << "Failed to run RPC task" << endl;
				taskStatusMutex.lock();
				reduceTaskStatus[file_shard_idx] = UNASSIGNED;
				workerStatus[worker] = UNRESPONSIVE;
				taskStatusMutex.unlock();
			}
		}
	}
}

/* CS6210_TASK: Here you go. once this function is called you will complete whole map reduce task and return true if succeeded */
bool Master::run() {
	// Doesn't seem to be supported by compiler
	// string output_dir_path = this->mr_spec.output_dir;
	// ofstream output_dir;
	// output_dir.open(output_dir_path);
	// if(!fs::exists(output_dir)) {
	// 	cout << "Creating output directory: " << output_dir_path << endl;
	// 	fs::create_directory(output_dir_path);
	// }
	// } else {
	// 	 fs_oper::remove_all(output_dir_path);
	// }

	cout << "Starting map tasks..." << endl;
	vector<std::thread> mapper_threads;
	for(int i = 0;i < this->mr_spec.n_workers;i++) {
		std::thread mapper_thread(&Master::run_map_task, this, mr_spec.worker_ipaddr_ports.at(i));
		mapper_threads.push_back(std::move(mapper_thread));
	}

	for(int i = 0;i < this->mr_spec.n_workers;i++) {
		mapper_threads.at(i).join();
	}
	cout << "All map tasks done!!" << endl;


	// This is important to initialize reduceFileShards
	reduceFileShards = createReduceFileShards(map_output_files);
	
	cout << "Starting reduce tasks..." << endl;
	vector<std::thread> reducer_threads;
	for(int i = 0;i < this->mr_spec.n_workers;i++) {
		std::thread reducer_thread(&Master::run_reducer_task, this, mr_spec.worker_ipaddr_ports.at(i));
		reducer_threads.push_back(std::move(reducer_thread));
	}

	for(int i = 0;i < this->mr_spec.n_workers;i++) {
		reducer_threads.at(i).join();
	}
	cout << "All reducer tasks done!!" << endl;

	// Cleanup map task intermediate files
	bool debug_keep_map_files = false;

	if(!debug_keep_map_files) {
		cout << "Cleaning up interim files from map task..." << endl;
		for(int i = 0;i < map_output_files.size();i++) {
			for(int j = 0;j < this->mr_spec.n_output_files;j++) {
				string map_output_file = map_output_files.at(i) + "." + to_string(j);
				int delete_status = remove(map_output_file.c_str());
			}
		}
	}
	cout << "Done running map reduce" << endl;

	return true;
}